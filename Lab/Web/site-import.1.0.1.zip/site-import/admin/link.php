<h3>Link</h3>
<h4>Add the link to website you want to import items from.</h4>

<table class="form-table">
	<tr>
		<td><label for="si-link">Link</label></td>
		<td><input type="text" value="" id="si-link"></td>
	</tr>
	<tr>
		<td></td>
		<td><input type="button" value="OK" id="si-link-check"></td>
	</tr>
</table>