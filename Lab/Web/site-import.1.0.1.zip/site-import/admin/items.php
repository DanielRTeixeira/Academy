<h3>Items</h3>
<h4>Select one item on the site, the others will be detected automatically.</h4>

<table class="form-table">
	<tr>
		<td><label for="si-item">Item</label></td>
		<td><input type="text" value="" id="si-item" disabled="disabled"></td>
	</tr>
	<tr>
		<td><label for="si-item-link">Item link</label></td>
		<td><input type="text" value="" id="si-item-link" disabled="disabled"></td>
	</tr>
	<tr>
		<td></td>
		<td><input type="button" value="OK" id="si-items-check"></td>
	</tr>
</table>

<h3>Pagination</h3>
<h4>Select pagination on the site if necessary.</h4>

<table class="form-table">
	<tr>
		<td><label for="si-pagination">Pagination</label></td>
		<td><input type="text" value="" id="si-pagination" disabled="disabled"></td>
	</tr>
</table>